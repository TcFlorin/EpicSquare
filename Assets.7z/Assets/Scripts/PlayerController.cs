﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    public float speed;
    public float jumpForce = 250.0f;
    float horSpeed = 3.5f;

    private Rigidbody2D myRigidbody;

    bool grounded = false;
    public Transform groundCheck;

    public float groundRadius;

    public LayerMask whatIsGround;

    public GameManager theGameManager;

    void Start()
    {
        myRigidbody = GetComponent<Rigidbody2D>();
        myRigidbody.mass = 0.45f;
        myRigidbody.gravityScale = 2.0f;
    }


    void FixedUpdate()
    {

        grounded = Physics2D.OverlapCircle(groundCheck.position, groundRadius, whatIsGround);

        float move = Input.GetAxis("Horizontal");
        GetComponent<Rigidbody2D>().velocity = new Vector2(move * speed, GetComponent<Rigidbody2D>().velocity.y);

        if (Input.GetKeyDown(KeyCode.Space) && grounded)
        {
            myRigidbody.AddForce(new Vector2(0, jumpForce));
        }
        if (Input.GetAxisRaw("Horizontal") != 0)
        {
            myRigidbody.velocity = new Vector2(Input.GetAxisRaw("Horizontal") * speed, myRigidbody.velocity.y);
        }
        else if (Input.GetAxisRaw("Horizontal") == 0)
        {
            myRigidbody.velocity = new Vector2(0, myRigidbody.velocity.y);
        }

    }

    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "killbox")
        {
            theGameManager.RestartGame();

        }
    }










}