﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

    public Transform UpGenerator;
    private Vector3 genStartPoint;

    public Transform MainCamera;
    private Vector3 CamStartPoint;

    public PlayerController thePlayer;
    private Vector3 playerStartPoint;

    private DownRemover[] DownRemoverList;

    public DeathMenu theDeathScreen;

    // Use this for initialization
    void Start() {
        genStartPoint = UpGenerator.position;
        playerStartPoint = thePlayer.transform.position;
        CamStartPoint = MainCamera.position;
    }

    // Update is called once per frame
    void Update() {

    }
    public void RestartGame()
    {

        thePlayer.gameObject.SetActive(false);

        theDeathScreen.gameObject.SetActive(true);
        //StartCoroutine("RestartGameCo");

    }
    public void Reset()
    {
        theDeathScreen.gameObject.SetActive(false);
        DownRemoverList = FindObjectsOfType<DownRemover>();
        for (int i = 0; i < DownRemoverList.Length; i++)
        {
            DownRemoverList[i].gameObject.SetActive(false);
        }


        thePlayer.transform.position = playerStartPoint;
        MainCamera.position = CamStartPoint;
        UpGenerator.position = genStartPoint;
        thePlayer.gameObject.SetActive(true);



    }


    /*public IEnumerator RestartGameCo()
    {
        thePlayer.gameObject.SetActive(false);

        yield return new WaitForSeconds(0.5f);

        DownRemoverList = FindObjectsOfType<DownRemover>();
        for(int i = 0;i < DownRemoverList.Length;i++)
        {
            DownRemoverList[i].gameObject.SetActive(false);
        }
        

        thePlayer.transform.position = playerStartPoint;
        MainCamera.position = CamStartPoint;
        UpGenerator.position = genStartPoint;
        thePlayer.gameObject.SetActive(true);



    }*/

}
