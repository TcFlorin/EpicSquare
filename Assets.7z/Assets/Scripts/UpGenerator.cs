﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpGenerator : MonoBehaviour {

    Transform Cam;


	void Start () {
        Cam = GameObject.Find("Main Camera").transform;
	}


    void Update() {
        if (gameObject.transform.position.y<Cam.position.y)
        {
           GameObject G = Instantiate(Resources.Load("Upwalls")) as GameObject;
            G.transform.position = gameObject.transform.position;
            gameObject.transform.Translate(0,  4.8f, 0);
        }
	}
   
}
