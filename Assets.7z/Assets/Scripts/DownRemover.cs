﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DownRemover : MonoBehaviour {

    Transform Cam;
	void Start () {
        Cam = GameObject.Find("Main Camera").transform;

	}
	
	// Update is called once per frame
	void Update () {
		if(gameObject.transform.position.y + 12 < Cam.position.y)
        {
            Destroy(gameObject);
        }
	}
}
