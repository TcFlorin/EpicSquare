﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SliderDiff : MonoBehaviour {

    


    public void Slider_Changed(float newValue)
    {
        PlayerPrefs.SetFloat("diff", newValue);
    }




    void Start () {
		


	}
	
	
	void Update () {
		
	}

   


}
