﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Freeze : MonoBehaviour {


    private Rigidbody2D rb ;
    bool isOnGround;
   


    void Start () {

       rb = GetComponent<Rigidbody2D>();
}


    void Update() {

      


        var vel = rb.velocity;
        float speed = vel.magnitude;

        if (speed == 0 && isOnGround)
        {
            gameObject.layer = LayerMask.NameToLayer("ground");
            rb.isKinematic = true;
        }

    }

    void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.layer == 8)
        {
            isOnGround = true;
        }
    }


    void OnCollisionExit2D(Collision2D col)
    {
        if (col.gameObject.layer == 8)
        {
            isOnGround = false;
        }
    }







}
