﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;


public class ScoreManager : MonoBehaviour
{

    public TextMeshProUGUI scoreText;
    int score;

    void Start()
    {
        score = 0;
        InvokeRepeating("IncrementScore", 3.0f, 0.5f);
    }


    void IncrementScore()
    {
        score++;
        scoreText.text = score.ToString();
    }
}
