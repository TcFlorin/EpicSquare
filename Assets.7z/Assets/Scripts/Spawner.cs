﻿using UnityEngine;

public class Spawner : MonoBehaviour {

    public Transform[] spawnLocations;
    public GameObject[] whatToSpawnPrefab;
    public GameObject[] whatToSpawnClone;
    int RandomLoc;
    float nrrand;
    

    void Update()
    {
        nrrand = PlayerPrefs.GetFloat("diff");
        if (Random.Range(0, 1000) < nrrand)
        {
        RandomLoc = Random.Range(0, 10);
        blockspawn();
    }
    }


    void blockspawn()
    {
        
            whatToSpawnClone[0] = Instantiate(whatToSpawnPrefab[0], spawnLocations[RandomLoc].transform.position, Quaternion.Euler(0, 0, 0)) as GameObject;
      
    }
}
